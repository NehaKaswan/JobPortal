let mongoose = require("mongoose")
let cateSchema = mongoose.Schema({
    category:{
        type :String,
        required :true
    }
})

// modal.exports = mongoose.module("category", cateSchema)
module.exports = mongoose.model("category" , cateSchema)