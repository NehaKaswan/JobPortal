// let category = require("../module/category");
// const Category = require('../module/Category');
let category = require('../module/Category')
let express = require("express");
let router = express.Router();

router.post("/api/addCategory", async(req, res) =>{
    try{
        let data = req.body;
        await category.create(data);
        res.status(200).json({msg: "Add Category !"});
    }catch(error){
        console.log(error);
        res.status(500).json({msg: "server error !"});
    }
});
router.get("/api/getCategory", async (req, res)=>{
    try {
        let allCategory =await category.find();
        res.status(200).json({allCategory});
    } catch (error) {
        console.log(error);
        res.status(500).json({msg: "server Error!"});
    }
});
router.get("/api/deleteCategory/:id", async(req, res)=>{
    let _id =req.params.id
    try {
        await Category.findOneAndDelete(_id)
        res.status(200).json({msg: "data Delete!"});
    } catch (error) {
        console.log(error);
        res.status(500).json({msg: "server Error!"});
    }
})
module.exports = router;