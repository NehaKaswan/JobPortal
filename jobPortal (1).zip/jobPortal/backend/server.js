let CategoryRoute = require("./routes/category");
let express = require("express");
let bcrypt = require("bcrypt");
let app = express();
let cors = require("cors");
let mongoose = require("mongoose");
let nodemailer = require("nodemailer");

// ✅ Email Transporter
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "",
    pass: "",
  },
});

app.use(cors());
app.use(express.json());
app.use("/", CategoryRoute);
let contactSchema = mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
  },
  subject: {
    type: String,
    required: true,
  },
  msg: {
    type: String,
    required: true,
  },
});
let signupSchema = mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
  },
  password: {
    type: String,
    required: true,
  },
  role: {
    type: String,
    required: true,
  },
});

let userSchema = mongoose.Schema({
  jobid: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "job",
    required: true,
  },
  userID: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "signup",
    required: true,
  },
});

let jobSchema = mongoose.Schema({
  imgPath: {
    type: String,
    required: true,
  },
  title: {
    type: String,
    required: true,
  },
  category: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "category",
    required: true,
  },

  openingDate: {
    type: String,
    required: true,
  },
  closingDate: {
    type: String,
    required: true,
  },
  location: {
    type: String,
    required: true,
  },
  openings: {
    type: String,
    required: true,
  },
});

let signups = mongoose.model("signup", signupSchema);
app.post("/api/signup", async (req, res) => {
  let sign = req.body;
  console.log(sign);
  try {
    let salt = await bcrypt.genSalt();
    let newPassword = await bcrypt.hash(sign.password, salt);
    sign.password = newPassword;
    console.log(sign);
    await signups.create(sign);
    res.status(200).json({ msg: "data save!" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ msg: "server error!" });
  }
});

app.post("/api/logina", async (req, res) => {
  let data = req.body;
  console.log(data);
  try {
    let find = await signups.findOne({ email: data.email });
    if (!find) {
      return res.status(401).json({ msg: " User not Found !" });
    }
    console.log(find);
    let match = await bcrypt.compare(data.password, find.password);
    if (!match) {
      return res.status(401).json({ msg: "password Not Match !" });
    }
    res
      .status(200)
      .json({
        name: find.name,
        email: find.email,
        role: find.role,
        userId: find._id,
      });
  } catch (error) {
    console.log(error);
  }
});

let Contacts = mongoose.model("contact", contactSchema);
app.post("/api/contact", async (req, res) => {
  let data = req.body;
  try {
    await Contacts.create(data);
    res.status(200).json({ msg: "data save!" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ msg: "server error!" });
  }
});
let userData = mongoose.model("userdata", userSchema);
app.post("/api/userid", async (req, res) => {
  let {jobid, userID} = req.body;
  console.log(jobid, userID)
  try {
      let userInfo = await signups.findOne( { _id: userID })
      let email = userInfo.email;
      let name = userInfo.name;
      let jobTitle = await Jobs.findOne({ _id: jobid });
      jobTitle = jobTitle.title;
    await userData.create({jobid, userID});
    const mailOptions = {
      from: "",
      to: email,
      subject: "Job Application Confirmation",
      text: `Dear ${name},Thank you for applying for the position of ${jobTitle}. We have received your application and will review it shortly. We will contact you if your qualifications match our requirements.`,
    };
    transporter.sendMail(mailOptions);
    res.status(200).json({ msg: "data save!" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ msg: "server error!" });
  }
});

app.get("/allSignup", async (req, res) => {
  try {
    let allSignup = await signups.find();
    res.json({ allSignup });
  } catch (error) {
    console.log(error);
    res.status(500).json({ msg: "server Error!" });
  }
});

app.get("/allContact", async (req, res) => {
  try {
    let allContact = await Contacts.find();
    res.json({ allContact });
  } catch (error) {
    console.log(error);
    res.status(500).json({ msg: "server Error!" });
  }
}); ////for fontend to data base

app.get("/api/deleteContact/:id", async (req, res) => {
  let id = req.params.id;
  try {
    await Contacts.findOneAndDelete(id);
    res.status(200).json({ msg: "data deleted!" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ msg: "server error!" });
  }
});

app.get("/api/deleteSignup/:id", async (req, res) => {
  let id = req.params.id;
  try {
    await signups.findOneAndDelete(id);
    res.status(200).json({ msg: "data deleted!" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ msg: "server error!" });
  }
});

let Jobs = mongoose.model("job", jobSchema);
app.post("/api/addJob", async (req, res) => {
  let job = req.body;
  console.log(job);
  try {
    await Jobs.create(job);
    res.status(200).json({ msg: "job save!" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ msg: "server error!" });
  }
});

app.put("/api/update/:id", async (req, res) => {
  let job = req.body;
  let id = req.params.id;
  try {
    await Jobs.findOneAndUpdate({ _id: id }, job);
    res.status(200).json({ msg: "job save!" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ msg: "server error!" });
  }
});

app.get("/allJob", async (req, res) => {
  try {
    let allJob = await Jobs.find().populate("category");
    res.json({ allJob });
    console.log(allJob);
  } catch (error) {
    console.log(error);
    res.status(500).json({ msg: "server Error!" });
  }
});

app.get("/getJobById/:id", async (req, res) => {
  let _id = req.params.id;
  try {
    let data = await Jobs.findOne({ _id });
    console.log(data);
    res.json(data);
  } catch (error) {
    console.log(error);
  }
});

app.get("/api/deleteJob/:id", async (req, res) => {
  let id = req.params.id;
  try {
    await Jobs.findOneAndDelete(id);
    res.status(200).json({ msg: "data deleted!" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ msg: "server error!" });
  }
});

app.get("/applyjob/:id", async (req, res) => {
  const userID = req.params.id;
  try {
    let allJob = await userData
      .find({ userID })
      .populate("jobid")
      .populate("userID");
    res.json({ allJob });
  } catch (error) {
    console.log(error);
    res.status(500).json({ msg: "server Error!" });
  }
});

app.delete("/api/applications/:id", async (req, res) => {
  const { id } = req.params;
  console.log(id);
  try {
    await userData.findByIdAndDelete(id);
    res.status(200).json({ message: "Application deleted" });
  } catch (err) {
    res.status(500).json({ error: "Failed to delete application" });
  }
});

mongoose
  .connect("mongodb://localhost:27017/jobProject")
  .then(() => {
    app.listen(4000, () => {
      console.log("hello start!");
    });
  })
  .catch((err) => console.log(err));
