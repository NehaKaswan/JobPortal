import Header from "../componnets/Header"
import Footer from "../componnets/Footer"
import { Outlet } from "react-router-dom"
function Layout() {
    return(
        <div>
            <Header/>
            <Outlet></Outlet>
            <Footer/>
        </div>
    )
}
export default Layout