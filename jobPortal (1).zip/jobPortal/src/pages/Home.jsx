import { Briefcase, MapPin, ChevronDown, Pyramid, BookOpenText, ArrowRight, GalleryThumbnails, ShieldUser, Presentation, CircleArrowRight, Mail, Volleyball } from "lucide-react";
import fb from "../assets/facebook-logo.png"
import gg from "../assets/google-logo.png"
import apk from "../assets/apk.png"
import ln from "../assets/ln.png"
import sky from "../assets/skype.png"
import snap from "../assets/snapchat.png"
import img1 from "../assets/img1.jpg"
import img2 from "../assets/img2.jpg"
import img3 from "../assets/img3.jpg"
import img4 from "../assets/img4.jpg"
import { Link } from "react-router-dom";

function Home() {
    let data = [
        {
            icon: <Pyramid />,
            title: "Business Development",
            desc: "74 Jobs"
        },
        {
            icon: <BookOpenText />,
            title: "Marketing & Communication",
            desc: "12 Jobs"
        },
        {
            icon: <GalleryThumbnails />,
            title: "Project Management",
            desc: "35 Jobs"
        },
        {
            icon: <ShieldUser />,
            title: "Customer Service",
            desc: "46 Jobs"
        },
        {
            icon: <Presentation />,
            title: "Software Engineering",
            desc: "60 Jobs"
        }
    ]
    let card2 = [
        {
            icon: fb,
            title: "Google",
            time: "2 Days Ago",
            button: "Part Time",
            place: "Marketing Director",
            locationIcon: <MapPin />,
            loction: "USA",
            vacany: "21 applied of 40 vacancy"
        },
        {
            icon: gg,
            title: "Google",
            time: "2 Days Ago",
            button: "Full Time",
            place: "Web Designer / Developer",
            locationIcon: <MapPin />,
            loction: "Australia",
            vacany: "21 applied of 40 vacancy"
        },
        {
            icon: apk,
            title: "Android",
            time: "2 Days Ago",
            button: "Remote",
            place: "Application Developer",
            locationIcon: <MapPin />,
            loction: "China",
            vacany: "21 applied of 40 vacancy"
        },
        {
            icon: ln,
            title: "Lenovo",
            time: "2 Days Ago",
            button: "WFH",
            place: "Senior Product Designer",
            locationIcon: <MapPin />,
            loction: "Dubai",
            vacany: "21 applied of 40 vacancy"
        },
        {
            icon: sky,
            title: "Skype",
            time: "2 Days Ago",
            button: "Full Time",
            place: "Web Designer / Developer",
            locationIcon: <MapPin />,
            loction: "Australia",
            vacany: "21 applied of 40 vacancy"
        },
        {
            icon: snap,
            title: "Snapchat",
            time: "2 Days Ago",
            button: "Remote Time",
            place: "PHP Developer",
            locationIcon: <MapPin />,
            loction: "India",
            vacany: "21 applied of 40 vacancy"
        }

    ] 
    
    return (
        <div>
            <div className="flex justify-center items-center bg-gray-200">

                <div className="relative">
                    <div className="bg-white  w-10 rounded-2xl p-2.5  absolute left-6/12 top-32 spinner-circle
">
                        <img src={fb} alt="" className="" />
                    </div>
                    <div className="bg-white  w-10 rounded-2xl p-2.5   absolute -left-4 top-66 spinner-circle">
                        <img src={gg} alt="" className="" />
                    </div><div className="bg-white  w-10 rounded-2xl p-2.5  absolute -right-8 top-66 spinner-circle">
                        <img src={apk} alt="" className="" />
                    </div>
                    <h1 className="text-5xl font-bold text-center mt-50">Join us & <span className="text-gray-400">Explore<br></br> Thousands</span> of Jobs</h1>
                    <p className="text-center text-2xl mt-5 font-light">Find Jobs, Employment & Career Opportunities. Some of the companies<br /> we've helped recruit excellent applicants over the years.</p>

                    <div className="bg-white  w-10 rounded-2xl p-2.5 absolute -left-24 bottom-68 spinner-circle">
                        <img src={ln} alt="" className="" />
                    </div>
                    {/* <div className="bg-gray-300 h-24 p-2 flex justify-center items-center mt-5">
                        <div className="relative items-center">
                            <span className="absolute inset-y-0 left-0  flex items-center pl-1"><Briefcase color="black" size={20} /></span>
                            <input type="text" placeholder="search your keywords" className="bg-white p-1 border-r-4 border-none h-16 border-r-amber-950 pl-7" />
                        </div>
                        <div className="relative border-l-1">
                            <span className="absolute top-5 left-1 pl-1"><MapPin /></span>
                            <input type="text" placeholder="search..." className="bg-white p-1 border-r-4 border-none h-16 pl-8" />
                            <span className="absolute right-1 top-4"><ChevronDown /></span>
                        </div>
                        <div className="relative border-l-1">
                            <span className="absolute top-5 left-1"><Briefcase /></span>
                            <input type="text" placeholder="select...." className="bg-white p-1 border-r-4 border-none h-16 pl-8" />
                            <span className="absolute right-1 top-4"><ChevronDown /></span>
                        </div>
                        <button className="bg-gray-400 text-3xl text-white p-4 pl-10 pr-10">Search</button>
                    </div> */}
                    <div className="bg-white  w-10 rounded-2xl p-2.5  absolute bottom-68 -right-24 spinner-circle">
                        <img src={sky} alt="" className="" />
                    </div>
                    <p className="text-center mt-5 font-light mb-50"><b>Popular job </b>: Designer, Developer, Web, IOS, PHP Senior Engineer
                    </p>
                </div>
                <div className="bg-white  w-10 rounded-2xl p-2.5  absolute left-6/12 -bottom-60 mb-5 spinner-circle">
                    <img src={snap} alt="" className="" />
                </div>
            </div>

            <div className="flex justify-center items-center">
                <div>
                    <h1 className="text-center text-4xl p-10">Popular Categories
                    </h1>
                    <p className="font-extralight text-center ">Search all the open positions on the web. Get your own personalized salary<br></br> estimate. Read reviews on over 30000+ companies worldwide.
                    </p>
                    <div className="flex justify-center items-center text-center gap-8">
                        {
                            data.map((val) => {
                                return (
                                    <Link to={"job"}> 
                                    <div className=" text-center p-12 mt-8 bg-gray-100 rounded-2xl">
                                        <div className="bg-gray-200  p-2 rounded-xl flex items-center justify-center">{val.icon}</div>
                                        <h1 className="m-1  font-medium text-xl">{val.title}</h1>
                                        <p className="mt-2 font-extralight">{val.desc}</p>
                                    </div>
                                    </Link>
                                )
                            })
                        }



                    </div>
                </div>
            </div>


            <div className="flex justify-center items-center gap-4 p-17 ">
                <div className="relative">
                    <img src={img1} alt="" className="w-150 rounded-xl" />
                    <img src={img2} alt="" className="absolute -bottom-32 left-40 w-75 border-10 border-[#ddd] rounded-xl" />
                </div>
                <div className="ml-40">
                    <h1 className="text-2xl font-semibold ">Millions of jobs.</h1>
                    <h1 className="text-2xl font-semibold pb-2"> Find the one that's right for you.
                    </h1>
                    <p className="pt-6 pb-6">Search all the open positions on the web. Get your own personalized salary estimate. Read reviews on over 30000+ companies worldwide.
                    </p>
                    <ul>
                        <li className="flex pl-2 mb-3">
                            <CircleArrowRight className="text-gray-500 mr-2" />Digital Marketing Solutions for Tomorrow
                        </li>
                        <li className="flex pl-2 mb-3">
                            <CircleArrowRight className="text-gray-500 mr-2" />Our Talented & Experienced Marketing Agency
                        </li>
                        <li className="flex pl-2">
                            <CircleArrowRight className="text-gray-500 mr-2" />Create your own skin to match your brand
                        </li>
                        <div>
                            <Link to={"contact"}>
                            <button className="bg-gray-800 pr-10 pl-10 p-2 text-xl rounded-2xl text-white mt-6 flex text-center"><Mail className="mt-1 mr-2" />contact us</button>
                            </Link>
                        </div>

                    </ul>
                </div>
            </div>
            <div>

                <div className="flex justify-center items-center mt-24 bg-gray-100">
                    <div>
                        <h1 className="text-center font-semibold text-4xl p-4">Popular Jobs
                        </h1>
                        <p className="text-center ">Search all the open positions on the web. Get your own personalized salary <br />estimate. Read reviews on over 30000+ companies worldwide.

                        </p>
                    </div>

                </div>
                <div className="bg-gray-100 grid grid-cols-3 gap-7 mb-8 pt-25 items-center p-14">
                    {
                        card2.map((val) => {
                            return (


                                <div className=" bg-white rounded-xl">
                                    <div className="flex gap-6 p-4">

                                        <div className="bg-gray-200 p-2 w-12 rounded-xl">
                                            <img src={val.icon} alt="" className="" />
                                        </div>

                                        <div>
                                            <h2 className="font-semibold">{val.title}</h2>
                                            <p className="text-gray-400">{val.time}</p>
                                        </div>
                                        <div>
                                            <button className="p-2 ml-6 rounded-xl bg-gray-400 text-amber-50">{val.button}</button>
                                        </div>

                                    </div>

                                    <div className="pl-6 p-2">
                                        <Link to="job" className="text-xl">{val.place}</Link>
                                        <span className="flex mt-2 mb-2">
                                            <h2>{val.locationIcon}</h2>
                                            <h2>{val.loction}</h2>
                                        </span>
                                        <div className="bg-gray-300 rounded-2xl w-70 h-2 mt-3 mb-3 relative">
                                            <div className="bg-gray-600 rounded-2xl w-25 h-2 mt-3 mb-3"></div>
                                        </div>
                                        <p className="text-gray-500 mb-4">{val.vacany}</p>
                                    </div>
                                </div>




                            )
                        })
                    }
                    <div className="text-gray-600 flex justify-center items-center">

                        <Link to="job">See More Jobs</Link>
                        <span><ArrowRight /></span>
                    </div>
                </div>
            </div>

            <div className="flex  items-center gap-30 justify-center w-full">

                <div className="">
                    <div className="">
                        <h1 className="text-2xl font-semibold p-6">Find Best Companies.</h1>
                        <p className="mb-4">Search all the open positions on the web. Get your own <br></br>personalized salary estimate. Read reviews on over 30000+ companies worldwide.</p>
                    </div>

                    <div className="grid grid-cols-2 gap-5">
                        {
                            card2.map((val) => {
                                return (
                                    <div className="bg-gray-300 rounded-2xl p-4">
                                        <div className="flex  items-center">
                                            <div className="bg-gray-200 p-2 w-12 rounded-xl">
                                                <img src={val.icon} alt="" className="" />
                                            </div>
                                            <h1 className="ml-4">{val.title}</h1>
                                        </div>
                                        <div className="ml-14 font-light text-gray-800">
                                            <p>2 vacancy</p>
                                        </div>
                                    </div>
                                )
                            }
                            )
                        }
                    </div>

                </div>
                <div className="relative">
                    <img src={img3} alt="" className="w-100 rounded-xl" />
                    <img src={img4} alt="" className="absolute -bottom-12 right-45 w-75 border-10 border-[#ddd] rounded-xl" />
                </div>
            </div>
        </div >
    )



}
export default Home;