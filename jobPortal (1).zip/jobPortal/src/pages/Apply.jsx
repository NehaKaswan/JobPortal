import React, { useState  ,useEffect} from 'react';
import JobApplications from '../componnets/JobApplications';
function Apply() {
    const [contact, setContact] = useState([]);

    async function getAllContact() {
      let userID =  localStorage.getItem("userID")
        try {
            const res = await fetch(`http://localhost:4000/applyjob/${userID}`);
            const data = await res.json();
            setContact(data.allJob);
        } catch (error) {
            console.error(error);
        }
    }
    
    useEffect(() => {
        getAllContact();
    }, []);



  return (
    <>
     <JobApplications applications={contact} />
    </>
    // <div className="min-h-screen flex items-center justify-center bg-gray-100">
    //   <form className="bg-white p-10 rounded shadow-md w-full max-w-lg">
    //     <h2 className="text-2xl font-semibold text-center mb-8">Apply for Job</h2>
        
    //     <table className="w-full table-auto">
    //       <tbody className="space-y-6">
    //         <tr className="align-top">
    //           <td className="py-3 pr-6 font-medium text-right align-middle">Name:</td>
    //           <td className="py-3">
    //             <input
    //               type="text"
    //               placeholder="Your Name"
    //               className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
    //             />
    //           </td>
    //         </tr>

    //         <tr className="align-top">
    //           <td className="py-3 pr-6 font-medium text-right align-middle">Email:</td>
    //           <td className="py-3">
    //             <input
    //               type="email"
    //               placeholder="Your Email"
    //               className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
    //             />
    //           </td>
    //         </tr>

    //         <tr className="align-top">
    //           <td className="py-3 pr-6 font-medium text-right align-middle">Apply For:</td>
    //           <td className="py-3">
    //             <input
    //               type="text"
    //               placeholder="You Apply For"
    //               className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
    //             />
    //           </td>
    //         </tr>

    //         <tr className="align-top">
    //           <td className="py-3 pr-6 font-medium text-right align-middle">Job Name:</td>
    //           <td className="py-3">
    //             <input
    //               type="text"
    //               placeholder="Job Name"
    //               className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
    //             />
    //           </td>
    //         </tr>

    //         <tr>
    //           <td></td>
    //           <td className="pt-6">
    //             <button
    //               type="submit"
    //               className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 transition-colors"
    //             >
    //               Delete Account
    //             </button>
    //           </td>
    //         </tr>
    //       </tbody>
    //     </table>
    //   </form>
    // </div>
  );
}

export default Apply;
