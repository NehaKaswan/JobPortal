import React, { useState } from 'react';
// import axios from "axios";

function Signup() {
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [role, setRole] = useState("apply"); // "apply" or "post"

    const submit = async (e) => {
        e.preventDefault();

       
    fetch("http://localhost:4000/api/signup", {
      method: "post",
      body: JSON.stringify({name, password, email, role
      }), headers: {
        "Content-Type": "application/json"
      }
    })
      .then(res => res.json())
      .then((data) => {
        alert(data.msg);
      })
      .catch(error => console.log(error))

    console.log({
      name,
      password,
      email,
      role
    }); alert("submitted")


        // Clear form fields
        setName("");
        setEmail("");
        setPassword("");
        setRole("");
        };

    return (
        <div>
            <div className="max-w-md mx-auto mt-10 p-6 bg-white rounded-lg shadow-md">
                <h2 className="text-2xl font-semibold text-center mb-6">Sign Up</h2>
                <form onSubmit={submit}>
                    <input
                        type="text"
                        placeholder="Name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full mb-4 px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                    />

                    <input
                        type="email"
                        placeholder="Email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full mb-4 px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                    />

                    <input
                        type="password"
                        placeholder="Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full mb-6 px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                    />
{/* 
                    <div className="mb-6">
                        <p className="mb-2 font-medium text-gray-700">I am here to:</p>
                        <div className="flex items-center space-x-6">
                            <label className="inline-flex items-center">
                                <input
                                    type="radio"
                                    name="userRole"
                                    value="apply"
                                    checked={role === "apply"}
                                    onChange={(e) => setRole(e.target.value)}
                                    className="form-radio h-4 w-4 text-blue-600"
                                    required
                                />
                                <span className="ml-2 text-gray-700">Apply for Job</span>
                            </label>

                            <label className="inline-flex items-center">
                                <input
                                    type="radio"
                                    name="userRole"
                                    value="post"
                                    checked={role === "post"}
                                    onChange={(e) => setRole(e.target.value)}
                                    className="form-radio h-4 w-4 text-blue-600"
                                />
                                <span className="ml-2 text-gray-700">Post a Job</span>
                            </label>
                        </div>
                    </div> */}

                    <button
                        type="submit"
                        className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 transition duration-200"
                    >
                        Sign Up
                    </button>
                </form>
            </div>
        </div>
    );
}

export default Signup;
