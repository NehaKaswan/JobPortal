import React, { useState, useContext } from 'react';
import { authContext } from '../context/AuthContextProvider';
import { useNavigate } from 'react-router-dom';
function Logina() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const navi = useNavigate()



  let { isLogin, setIsLogin } = useContext(authContext)

  const submit = async (e) => {
    e.preventDefault();
    
    try {
      let res = await fetch("http://localhost:4000/api/logina", {
        method: "post",
        body: JSON.stringify({ password, email }),
        headers: {
          "Content-Type": "application/json"
        }
      })
      let data = await res.json()

      if (res.ok) {
        localStorage.setItem("userID", data.userId)
        setIsLogin(true)
        navi("/");
      } else {
        alert(data.msg)
      }

    } catch (error) {
      console.log(error)
    }
    setEmail("");
    setPassword("");
  }



  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <div className="bg-white p-8 rounded shadow-md w-full max-w-sm">
        <h2 className="text-2xl font-bold mb-6 text-center">Login</h2>
        <form action="" onSubmit={submit}>

          <input
            type="text"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full px-4 py-2 mb-4 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-400"
          />

          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full px-4 py-2 mb-6 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-400"
          />

          <button

            className="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600 transition duration-200">
            Login
          </button>
        </form>
      </div>
    </div>
  );
}

export default Logina;
