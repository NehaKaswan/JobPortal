import img from "../assets/2.png"
import { Flag, Search, UserMinus} from "lucide-react";
import { Link } from "react-router-dom";
import { authContext } from "../context/AuthContextProvider";
import { useContext } from "react";
function Header() {
    let { isLogin, setIsLogin } = useContext(authContext)
    console.log(isLogin)
    return (
        <div className="flex justify-between px-19 items-center bg-gray-600">

            <span>
                <img src={img} alt="" className="h-22 w-22 rounded-2xl" />
            </span>
            <div className="flex gap-12 font-semibold text-white text-xl">
                <Link to={"/"} className="hover:font-extrabold text-xl">Home</Link>
                <Link to={"/about"} className="hover:font-extrabold text-xl">About</Link>
                <Link to={"/contact"} className="hover:font-extrabold text-xl">Contact us</Link>
                <Link to={"/job"} className="hover:font-extrabold text-xl">Jobs</Link>
                <Link to={"/login"} href="">Admin Login</Link>
                {
                    isLogin ? (<>
                        <Link  onClick={()=>{
                            setIsLogin(false)
                            localStorage.removeItem("userID")
                            
                        }}><UserMinus/></Link>
                        <Link to={"/Apply"} className="hover:font-extrabold text-xl">Account</Link>
                        </>
                    ) : (
                        <>
                            <Link to={"/logina"} href="">Login</Link>
                            <Link to={"/signup"} href="">Sign</Link>
                        </>
                    )
                }

            </div>
            {/* <div className="relative">
                <input type="text" placeholder="search...." className="bg-white p-1 border-r-4 border-none rounded-2xl" />
                <span className="absolute right-2 top-1.5"> <Search color="black" size={20} /></span>
            </div> */}
        </div>
    )
}
export default Header;