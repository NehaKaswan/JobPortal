import { useState } from "react";
import { useNavigate } from "react-router-dom";

function Login() {
    const [userName, setUserName] = useState("");
    const [password, setPassword] = useState("");
    const navi = useNavigate();

    function adminlogin() {
        if (userName === "admin" && password === "1234") {
            alert("Admin login");
            navi("/admin");
        } else {
            alert("Error!");
        }
    }

    return (
        <div className="flex items-center justify-center min-h-screen bg-gray-200">
            <div className="group bg-white/70 backdrop-blur-sm p-8 rounded-lg shadow-xl w-full max-w-sm border border-gray-300 transition duration-300 transform hover:shadow-2xl hover:scale-105">
                <h2 className="text-2xl font-bold mb-6 text-center text-gray-800 group-hover:text-gray-900 transition-colors">
                    Admin Login
                </h2>

                <input
                    type="text"
                    value={userName}
                    placeholder="Enter Username"
                    onChange={(e) => setUserName(e.target.value)}
                    className="w-full px-4 py-2 mb-4 border border-gray-300 rounded-md text-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 bg-white/90 placeholder-gray-500"
                />

                <input
                    type="password"
                    value={password}
                    placeholder="Enter Password"
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full px-4 py-2 mb-6 border border-gray-300 rounded-md text-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 bg-white/90 placeholder-gray-500"
                />

                <button
                    onClick={adminlogin}
                    className="w-full bg-gray-700 text-white py-2 rounded-md hover:bg-gray-800 transition duration-300"
                >
                    Login
                </button>
            </div>
        </div>
    );
}

export default Login;
