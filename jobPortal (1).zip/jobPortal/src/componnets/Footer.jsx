import React from 'react';

const Footer = () => {

  // console.log(new Date().getHours()) 
  // console.log(new Date().getMinutes()) 
  // console.log(new Date().getSeconds()) 
  // // console.log(new Date().Seconds()) 
  
  return (
    <footer className="bg-gray-700 text-white py-10">
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-4 gap-8">
        
        {/* Logo & Description */}
        <div>
          <h2 className="text-2xl font-bold mb-3">JobStack</h2>
          <p className="text-sm text-gray-300">
            Connecting job seekers with top employers across industries. Find your next opportunity today.
          </p>
        </div>

        {/* Quick Links */}
        <div>
          <h3 className="text-lg font-semibold mb-3">Quick Links</h3>
          <ul className="space-y-2 text-sm text-gray-300">
            <li><a href="#" className="hover:underline">Jobs</a></li>
            <li><a href="#" className="hover:underline">Companies</a></li>
            <li><a href="#" className="hover:underline">About Us</a></li>
            <li><a href="#" className="hover:underline">Contact</a></li>
          </ul>
        </div>

        {/* Resources */}
        <div>
          <h3 className="text-lg font-semibold mb-3">Resources</h3>
          <ul className="space-y-2 text-sm text-gray-300">
            <li><a href="#" className="hover:underline">Blog</a></li>
            <li><a href="#" className="hover:underline">FAQ</a></li>
            <li><a href="#" className="hover:underline">Help Center</a></li>
            <li><a href="#" className="hover:underline">Privacy Policy</a></li>
          </ul>
        </div>

        {/* Contact Info */}
        <div>
          <h3 className="text-lg font-semibold mb-3">Contact Us</h3>
          <p className="text-sm text-gray-300"> Sirsa,<br />Tech City,10101</p>
          <p className="text-sm text-gray-300 mt-2">Email: support@jobstack.com</p>
          <p className="text-sm text-gray-300">Phone: +19 97123-40567</p>
          {/* Social Icons */}
          <div className="flex space-x-4 mt-4">
            <a href="#" className="text-gray-300 hover:text-white text-xl"><i className="fab fa-facebook-f"></i></a>
            <a href="#" className="text-gray-300 hover:text-white text-xl"><i className="fab fa-twitter"></i></a>
            <a href="#" className="text-gray-300 hover:text-white text-xl"><i className="fab fa-linkedin-in"></i></a>
            <a href="#" className="text-gray-300 hover:text-white text-xl"><i className="fab fa-instagram"></i></a>
          </div>
        </div>
      </div>

      {/* Bottom Line */}
      <div className="mt-10 border-t border-gray-600 pt-6 text-center text-sm text-gray-400">
        © {new Date().getFullYear()} JobStack. All rights reserved.
      </div>
    </footer>
  );
};

export default Footer;
