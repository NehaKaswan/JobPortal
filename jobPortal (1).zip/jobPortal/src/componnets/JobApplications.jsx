import React, { useState } from 'react';

const JobApplications = ({ applications }) => {
  const handleRemove = async (idToRemove) => {
    const confirm = window.confirm("Are you sure you want to delete this application?");
    if (!confirm) return;
    try {
      const response = await fetch(`http://localhost:4000/api/applications/${idToRemove}`, {
        method: 'DELETE',
      });

      if (!response.ok) {
        throw new Error('Failed to delete application');
      }
      alert("Application deleted successfully!");
      window.location.reload(); // Refresh the page to reflect changes
    } catch (error) {
      console.error("Error deleting application:", error);
      alert("Failed to delete. Please try again.");
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <h1 className="text-3xl font-bold text-center mb-8">Job Applications</h1>
      
      {applications.length === 0 ? (
        <p className="text-center text-gray-500">No applications found.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {applications.map((app, index) => {
            const { jobid, userID } = app;

            return (
              <div key={index} className="bg-white shadow-md rounded-lg overflow-hidden relative">
                <img src={jobid.imgPath} alt={jobid.title} className="w-full h-40 object-cover" />

                <div className="p-4">
                  <h2 className="text-xl font-semibold text-gray-800 mb-2">{jobid.title}</h2>
                  <p className="text-gray-600 mb-1"><strong>Location:</strong> {jobid.location}</p>
                  <p className="text-gray-600 mb-1"><strong>Openings:</strong> {jobid.openings}</p>
                  <p className="text-gray-600 mb-1"><strong>Open Date:</strong> {jobid.openingDate}</p>
                  <p className="text-gray-600 mb-3"><strong>Close Date:</strong> {jobid.closingDate}</p>

                  <div className="border-t pt-3 mt-3">
                    <p className="text-gray-700 text-sm"><strong>Applicant:</strong> {userID.name}</p>
                    <p className="text-gray-700 text-sm"><strong>Email:</strong> {userID.email}</p>
                  </div>

                  <button
                    onClick={() => handleRemove(app._id)}
                    className="mt-4 w-full bg-red-500 hover:bg-red-600 text-white font-semibold py-2 px-4 rounded transition"
                  >
                    Remove
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default JobApplications;

