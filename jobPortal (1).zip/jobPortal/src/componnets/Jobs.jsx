import { useState, useEffect ,useContext } from "react";
import axios from "axios"
import { authContext } from "../context/AuthContextProvider";

function Jobs() {
  const [job, setJob] = useState([]);
let {handelApply} =  useContext(authContext)
  async function getAllJob() {
    try {
      const res = await fetch("http://localhost:4000/allJob");
      const data = await res.json();
      // console.log(data);
      setJob(data.allJob);
    } catch (error) {
      console.error(error);
    }
  }
  useEffect(() => {
    getAllJob()
  }, [])

 
  return (
    <>
      <h1 className=" text-6xl font-bold text-center my-7"> All Jobs</h1>
    <div className="grid grid-cols-3 gap-4 p-4">
      {
        job.map((item) => {
          return (
            <div key={item._id} className="border-2 border-gray-200 rounded-lg shadow-md p-6 mb-6 bg-white hover:shadow-lg transition-shadow duration-300">
              {/* Top Row: Image + Title + Category */}
              <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-4">
                <img src={item.imgPath} alt={item.title} className="w-24 h-24 object-cover rounded-md" />

                <h1 className="text-1xl md:text-2xl font-bold text-gray-800 text-center md:text-left">
                  {item.title}
                </h1>

                <p className="text-lg  font-medium text-gray-600">
                  {item.category?.category}
                </p>
              </div>

              {/* Job Details */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-gray-700 text-base md:text-lg mb-4">
                <p><span className="font-semibold">Opening Date:</span> {item.openingDate}</p>
                <p><span className="font-semibold">Closing Date:</span> {item.closingDate}</p>
                <p><span className="font-semibold">Location:</span> {item.location}</p>
                <p><span className="font-semibold">Openings:</span> {item.openings}</p>
              </div>

              {/* Apply Button */}
              <div className="text-right">
                <button
                  id={item._id}
                  onClick={()=>{handelApply(item._id)}}
                  className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-2 rounded-md transition duration-200"
                >
                  Apply
                </button>
              </div>
            </div>

          )
        })
      }




    </div>
    </>
  )
}

export default Jobs;