import { Phone, Mail, MapPin } from "lucide-react";
import con1 from "../assets/con1.svg"
import { useState } from "react";
function Contact() {
    let cont = [
        {
            icon: <Phone />,
            heading: "Phone",
            title: "The phrasal sequence of the is now so that many campaign and benefit",
            contact: "+91 97123-40567"
        },
        {
            icon: <Mail />,
            heading: "Email",
            title: "The phrasal sequence of the is now so that many campaign and benefit",
            contact: "contact@jobstack.com"
        },
        {
            icon: <MapPin />,
            heading: "Location",
            title: "Sirsa,Tech City,10101",
            contact: "View on Google map"
        }
    ]

    let [name, SetName] = useState("");
    let [email, SetEmail] = useState("");
    let [msg, SetMsg] = useState("");
    let [subject, SetSubject] = useState("");

    function login() {
        fetch("http://localhost:4000/api/contact", {
            method: "post",
            body: JSON.stringify({ name, email, subject, msg }),
            headers: {
                "content-type": "application/json"
            }
        })
            .then(res => res.json())
            .then(data => alert(data.msg))
            .catch(err => console.log(err)
            )
    }

    return (
        <div>

            <div className="flex justify-center items-center gap-16">
                <img src={con1} alt="" className="w-150" />

                <div className="border-2 border-[#ddd] p-6">
                    <h1 className="p-4 text-2xl font-semibold">Get in touch !</h1>
                    <div className="">

                        <form action="" className="">

                            {/* //labelfor username */}
                            <label htmlFor="yourname" className="p-2 text-xl">Your Name:</label>

                            <input type="text"
                                id="yourname"
                                placeholder="Name:"
                                value={name}
                                className="border-2 border-gray-500  m-4 p-1.5"
                                onChange={(e) => {
                                    SetName(e.target.value)
                                }} />
                            <br />

                            {/* //label fro emailid */}
                            <label htmlFor="youremail" className="p-2 text-xl">Your Email:</label>
                            <input type="text"
                                id="youremail"
                                placeholder="Email:"
                                value={email}
                                className="border-2 border-gray-500 m-4 p-1.5"
                                onChange={(e) => { SetEmail(e.target.value) }} />
                            <br />

                            {/* //label for Question */}
                            <label htmlFor="yourquestion" className="p-2 text-xl">Your Question:</label>
                            <input type="text"
                                id="yourquestion"
                                placeholder="Subject:"
                                value={subject}
                                className="border-2 border-gray-500 m-4 p-1.5"
                                onChange={(e) => { SetSubject(e.target.value) }} />
                            <br />

                            {/* //label for Comment  textarea */}
                            <label htmlFor="text" className="p-2 text-xl">Your Comment:</label><br />
                            <textarea name=""
                                id="text"
                                className="border-2 border-gray-500 m-4 p-1.5"
                                placeholder="message"
                                value={msg}
                                onChange={(e) => { SetMsg(e.target.value) }}>

                            </textarea>
                        </form>
                        <button className="bg-gray-800  text-white font-semibold rounded-xl p-3 m-4" onClick={login}
                        >Send Message</button>
                    </div>
                </div>
            </div>
            <div className="flex justify-center items-center gap-4 p-14">
                {
                    cont.map((val, idx) => {
                        return (
                            <div key={idx} className="border-[#ddd] border-1 p-10 rounded-2xl">
                                <div className="bg-gray-200 p-3 w-12 rounded-xl ml-24 m-4">
                                    <h1 className="text-center">{val.icon}</h1>
                                </div>
                                <h1 className="p-2 ml-24 font-semibold text-xl">{val.heading}</h1>
                                <p className="ml-8 text-gray-400">{val.title}</p>
                                <a href="" className="ml-16 pt-4 text-gray-900 ">{val.contact}</a>
                            </div>
                        )
                    }
                    )
                }
            </div>
        </div>
    )
}
export default Contact;