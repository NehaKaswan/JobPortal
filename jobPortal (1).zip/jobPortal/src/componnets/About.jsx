import React, { useEffect, useState } from 'react'
import img from "../assets/about.jpg"
import getimg from "../assets/geabout.jpg"
import { Play, Smile } from "lucide-react";
function About() {
    const [count, setCount] = useState(0);

    useEffect(() => {
        console.log(count);
        if (count >= 4980) return; // Stop at 100

        const interval = setInterval(() => {
            setCount(prevCount => {
                if (prevCount >= 4980) {
                    clearInterval(interval);
                    return prevCount;
                }
                return prevCount + 1;
            });
        }, 100); // Adjust speed here (100ms per increment)

        return () => clearInterval(interval); // Cleanup
    }, [count]);



return (
    <div>
        <div className='flex justify-center items-center p-5 relative'>
            <img src={img} alt="" className='rounded-4xl ' />
            <div className='bg-gray-400'>
                {/* <h1><Smile />JOBS!</h1> */}
            </div>
        </div>

        <div className='flex justify-center items-center gap-14 bg-gray-700  m-30 relative rounded-xl'>
            <button className='absolute  text-gray-500  bg-[#ddd] p-9 rounded-full'></button>
            <img src={getimg} alt="" className='w-1/2 rounded-xl' />
            <div className='w-1/2 text-white'>
                <h1 className='text-5xl  pb-8'>Get the job of your
                    dreams quickly.</h1>
                <p className='text-xl pb-4'>Search all the open positions on the web. Get your own personalized salary estimate. Read reviews on over 30000+ companies worldwide.</p>
                <ul className='text-xl'>
                    <li className='p-1'>--Digital Marketing Solutions for Tomorrow</li>
                    <li className='p-1'>--Our Talented & Experienced Marketing Agenc</li>
                    <li className='p-1'>--Create your own skin to match your brand</li>
                </ul>
            </div>
        </div>

        <div className='flex justify-center items-center gap-5'>
            <div >
                <h1 className='font-bold text-5xl mr-40'>{count}+</h1>
                <p className='text-xl p-2'>Job Fulfillment</p></div>
            <div>
                <h1 className='font-bold text-5xl mr-40'>{count}+</h1>
                <p className='text-xl p-2'>Branches</p>
            </div>
            <div>
                <h1 className='font-bold text-5xl'>90+</h1>
                <p className='text-xl p-2'>Years Experience</p>
            </div>
        </div>
    </div>

)}
export default About
