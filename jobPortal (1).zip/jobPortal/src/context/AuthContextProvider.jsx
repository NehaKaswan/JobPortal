import React, { useEffect, useState } from 'react'
import { createContext } from 'react' 


export let  authContext =  createContext()

function AuthContextProvider({children}) {
    let [isLogin , setIsLogin] = useState(false)
    let userID =  localStorage.getItem("userID")

  useEffect(()=>{    
    if (!userID) {
      setIsLogin(false)
    }else{
      setIsLogin(true)
    }
    
  },[isLogin])

   function handelApply(jobid){
    if(!isLogin){
      return alert("plz login !")
    }
     fetch("http://localhost:4000/api/userid", {
      method: "post",
      body: JSON.stringify({jobid, userID
      }), headers: {
        "Content-Type": "application/json"
      }
    })
      .then(res => res.json())
      .then((data) => {
        alert(data.msg);
      })
      .catch(error => console.log(error))

    console.log(jobid)
  }
  return (
    <div>
        <authContext.Provider value={{isLogin , setIsLogin , handelApply}}>
            {children}
        </authContext.Provider>
      
    </div>
  )
}

export default AuthContextProvider
