import React from 'react';
import { useState, useEffect } from 'react';
function Addjob() {
    let [imgPath, setImgPath] = useState("")
    const [allCategory, setAllCategory] = useState([]);
    let [Title, setTitle] = useState("")
    let [depart, setDepart] = useState("")
    let [otime, setOtime] = useState("")
    let [ctime, setCtime] = useState("")
    let [location, setLocation] = useState("")
    let [open, setOpen] = useState("")


    // Fetch all categories
    async function getAllCategory() {
        try {
            const res = await fetch("http://localhost:4000/api/getCategory");
            const data = await res.json();
            setAllCategory(data.allCategory);
        } catch (error) {
            console.log(error);
        }
    }

    useEffect(() => {
        getAllCategory()
    }, [])
    async function handleFile(e) {
        let file = e.target.files[0]
        let formData = new FormData()
        formData.append("file", file)
        formData.append("upload_preset", "image123")
        try {
            let res = await fetch(
                "https://api.cloudinary.com/v1_1/dck9gnfbe/image/upload",
                {
                    method: "post",
                    body: formData,
                }
            )
            let data = await res.json()
            setImgPath(data.secure_url)
            console.log(data.secure_url);
        } catch (error) {
            console.log(error);
        }

    }
    async function submit(e) {
        e.preventDefault(); // Prevent page reload

        const jobData = {
            imgPath,
            title: Title,
            category: depart,
            openingDate: otime,
            closingDate: ctime,
            location,
            openings: open,
        };

        try {
            const res = await fetch("http://localhost:4000/api/addJob", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(jobData)
            });

            const data = await res.json();

            if (res.ok) {
                console.log("Job saved:", data);
                alert("Job submitted successfully!");
            } else {
                console.error("Error saving job:", data.error);
                alert("Failed to submit job.");
            }
        } catch (err) {
            console.error("Request failed:", err);
            alert("Server error occurred.");
        }
    }



    return (
        <div className="max-w-2xl mx-auto p-8 mt-10 bg-white shadow-md rounded-lg">
            <h2 className="text-2xl font-semibold text-gray-800 mb-6">Post a New Job</h2>
            <form className="space-y-5" onSubmit={submit}>

                {/* Image Upload */}
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor="jobImage">
                        Upload Image
                    </label>
                    <input
                        onChange={handleFile}
                        id="jobImage"
                        type="file"
                        className="block w-full text-sm text-gray-700 border border-gray-300 rounded-md cursor-pointer bg-gray-50 focus:outline-none focus:ring-1 focus:ring-blue-500"
                    />
                </div>

                {/* Title */}
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor="jobTitle">
                        Job Title
                    </label>
                    <input

                        id="jobTitle"
                        type="text"
                        value={Title}
                        onChange={(e) => setTitle(e.target.value)}
                        placeholder="UI/UX Designer"
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                </div>




                {/* Department */}
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor="department">
                        Department
                    </label>
                    <select
                        id="department"
                        value={depart}
                        onChange={(e) => setDepart(e.target.value)}
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                        <option value="">Select Department</option>
                        {
                            allCategory.map((val) => <option value={val._id}>{val.category}</option>)
                        }

                    </select>
                </div>

                {/* Dates */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor="openingDate">
                            Opening Date
                        </label>
                        <input
                            id="openingDate"
                            type="date"
                            value={otime}
                            onChange={(e) => setOtime(e.target.value)}
                            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor="closingDate">
                            Closing Date
                        </label>
                        <input
                            value={ctime}
                            onChange={(e) => setCtime(e.target.value)}
                            id="closingDate"
                            type="date"
                            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                    </div>
                </div>

                {/* Location */}
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor="location">
                        Location
                    </label>
                    <input
                        value={location}
                        onChange={(e) => setLocation(e.target.value)}
                        id="location"
                        type="text"
                        placeholder="Remote or New York"
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                </div>

                {/* Total Openings */}
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor="totalOpenings">
                        Total Openings
                    </label>
                    <input
                        value={open}
                        onChange={(e) => setOpen(e.target.value)}
                        id="totalOpenings"
                        type="number"
                        placeholder="3"
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                </div>

                {/* Submit Button */}
                <div>
                    <button

                        type="submit"
                        className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition duration-200"
                    >
                        Submit Job
                    </button>
                </div>
            </form>
        </div>
    );
}

export default Addjob;
