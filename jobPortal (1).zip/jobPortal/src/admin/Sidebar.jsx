import React from 'react'

import { Link } from "react-router-dom"

function Sidebar() {
  return (
    <div className='border h-screen p-10 bg-black text-white text-2xl'>
      <Link to={"ViewContact"} >viewContact</Link><br />
      <Link to={"AddCategory"} >AddCategory</Link><br />
      <Link to={"ViewCategory"} >ViewCategory</Link><br />
      <Link to={"Addjob"}>Addjob</Link><br />
      <Link to={"Viewjob"}>Viewjob</Link><br />
      <Link to={"Viewsignup"}>Viewsignup</Link>

    </div>
  )
}

export default Sidebar
