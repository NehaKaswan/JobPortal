import { Outlet } from "react-router-dom";
import Sidebar from "./Sidebar";
function AdminLayout() {
    return(
        <div className="flex gap-4">
            <Sidebar></Sidebar>
            <Outlet></Outlet>

        </div>
    )
}
export default AdminLayout;