import React, { useEffect, useState } from 'react';

function Viewsignup() {
  const [signup, setSignup] = useState([]); // ✅ Step 1: Define state

  // ✅ Step 2: Fetch signup data from server
  async function getAllSignup() {
    try {
      const res = await fetch("http://localhost:4000/allSignup"); // ✅ Corrected endpoint
      const data = await res.json();
      setSignup(data.allSignup); // ✅ Set fetched data
    } catch (error) {
      console.error("Failed to fetch signup data:", error);
    }       
  }

  // ✅ Step 3: Call getAllSignup when component mounts
  useEffect(() => {
    getAllSignup();
  }, []);
   async function deleteSignup(id){
        try {
            
     
            let res = await fetch(`http://localhost:4000/api/deleteSignup/${id}`);
          
            
            let data =await res.json();
            if(res.ok){
                getAllSignup()
            }
            console.log(data); 
        } catch (error) {
            console.log(error);
        }
    }

  return (
    <div>
      <table>
        <thead className="bg-gray-100 text-gray-700 text-xs uppercase tracking-wider">
          <tr>
            <th className="px-6 py-3">Sr</th>
            <th className="px-6 py-3">Name</th>
            <th className="px-6 py-3">Email</th>
            <th className="px-6 py-3">Password</th>
            <th className="px-6 py-3">Apply For</th>
            <th className="px-6 py-3 text-center">Actions</th>
          </tr>
        </thead>
        <tbody>
          {signup.map((c, idx) => (
            <tr
              key={c._id || idx}
              className={`${
                idx % 2 === 0 ? "bg-white" : "bg-gray-50"
              } hover:bg-gray-100 text-sm text-gray-700`}
            >
              <td className="py-3 px-5 border-b">{idx + 1}</td>
              <td className="py-3 px-5 border-b">{c.name}</td>
              <td className="py-3 px-5 border-b">{c.email}</td>
              <td className="py-3 px-5 border-b">{c.password}</td> {/* or c.password */}
              <td className="py-3 px-5 border-b">{c.role}</td>
              <td className="py-3 px-5 border-b text-center">
                {/* Optional Delete Button */}
                <button onClick={() => deleteSignup(c._id)}   className="bg-red-500 hover:bg-red-600 text-white font-semibold text-sm px-4 py-2 rounded shadow transition duration-200"
>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Viewsignup;
