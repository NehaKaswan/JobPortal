import React from 'react'
import {  Trash2 } from 'lucide-react'
import { useState, useEffect } from 'react'
import {Link} from "react-router-dom"
function Viewjobs() {
  const [job, setJob] = useState([]);

  async function getAllJob() {
    try {
      const res = await fetch("http://localhost:4000/allJob");
      const data = await res.json();
      // console.log(data);
      setJob(data.allJob);
    } catch (error) {
      console.error(error);
    }
  }
  async function deleteJob(id) {
    try {
      const res = await fetch(`http://localhost:4000/api/deleteJob/${id}`);
      const data = await res.json();
      if (res.ok) {
        getAllJob(); // Refresh the list
        console.log(data);
      }
    } catch (error) {
      console.log(error);
    }
  }

  useEffect(() => {
    getAllJob();
  }, []);
  console.log(job);

  return (
    <div>

      <table classn="min-w-full table-auto border-collapse">
        <thead class="bg-gray-100">
          <tr>
            <th class="px-4 py-2 text-left text-gray-700 font-semibold border-b">Sr</th>
            <th class="px-4 py-2 text-left text-gray-700 font-semibold border-b">Img</th>
            <th class="px-4 py-2 text-left text-gray-700 font-semibold border-b">Title</th>
            <th class="px-4 py-2 text-left text-gray-700 font-semibold border-b">Category</th>
            <th class="px-4 py-2 text-left text-gray-700 font-semibold border-b">Opening Date</th>
            <th class="px-4 py-2 text-left text-gray-700 font-semibold border-b">Closing Date</th>
            <th class="px-4 py-2 text-left text-gray-700 font-semibold border-b">Location</th>
            <th class="px-4 py-2 text-left text-gray-700 font-semibold border-b">Openings</th>
            <th class="px-4 py-2 text-left text-gray-700 font-semibold border-b">Buttons</th>

          </tr>
        </thead>

        <tbody>

          {job.map((c, idx) => (
            <tr
              key={idx}
              className={`${idx % 2 === 0 ? "bg-white" : "bg-gray-50"
                } hover:bg-gray-100 text-sm text-gray-700`}
            >
              <td className="py-3 px-5 border-b">{idx + 1}</td>
              <td>
                <img src={c.imgPath} alt=""
                  className="py-3 px-5 border-b" />
              </td>
              {/* <td className="py-3 px-5 border-b">{c.imgPath}</td> */}
              <td className="py-3 px-5 border-b">{c.title}</td>
              <td className="py-3 px-5 border-b">{c.category?.category}</td>
              <td className="py-3 px-5 border-b">{c.openingDate}</td>
              <td className="py-3 px-5 border-b">{c.closingDate}</td>
              <td className="py-3 px-5 border-b">{c.location}</td>
              <td className="py-3 px-5 border-b">{c.openings}</td>

              <td className="py-3 px-5 border-b">
                <button className="flex items-center gap-2 bg-slate-600 hover:bg-slate-700 text-white text-xs px-3 py-1 rounded transition duration-200" onClick={() => { deleteJob(c._id) }} >
                  <Trash2 />
                </button>
                <Link to={`/admin/jobupdate/${c._id}`} className="flex items-center gap-2 bg-slate-600 hover:bg-slate-700 text-white text-xs px-3 py-1 rounded transition duration-200"  >
                  Update
                </Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

    </div>
  )
}

export default Viewjobs
