import React, { useEffect, useState } from 'react';

function ViewCategory() {
    const [allCategory, setAllCategory] = useState([]);

    // Fetch all categories
    async function getAllCategory() {
        try {
            const res = await fetch("http://localhost:4000/api/getCategory");
            const data = await res.json();
            setAllCategory(data.allCategory);
        } catch (error) {
            console.log(error);
        }
    }

    // Delete a category by ID
    async function deleteCategory(id) {
        try {
            const res = await fetch(`http://localhost:4000/api/deleteCategory/${id}`);
            const data = await res.json();
            if (res.ok) {
                getAllCategory(); // Refresh the list
                console.log(data);
            }
        } catch (error) {
            console.log(error);
        }
    }

    // Run on component mount
    useEffect(() => {
        getAllCategory();
    }, []);

    return (
        <div className="min-h-screen bg-gray-100 py-10 px-4">
            <div className="max-w-3xl mx-auto bg-white p-6 rounded-lg shadow-md">
                <h2 className="text-2xl font-semibold text-gray-800 mb-4">All Categories</h2>

                {allCategory.length === 0 ? (
                    <p className="text-gray-500">No categories found.</p>
                ) : (
                    <ul className="space-y-3">
                        {allCategory.map((val) => (
                            <li
                                key={val._id}
                                className="flex items-center justify-between bg-gray-50 p-3 rounded-md border"
                            >
                                <span className="text-gray-800">{val.category}</span>
                                <button
                                    onClick={() => deleteCategory(val._id)}
                                    className="text-red-600 hover:text-red-800 text-sm font-medium"
                                >
                                    Delete
                                </button>
                            </li>
                        ))}
                    </ul>
                )}
            </div>
        </div>
    );
}

export default ViewCategory;
