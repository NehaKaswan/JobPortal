import React, { useState } from 'react';

function AddCategory() {
    const [category, setCategory] = useState('');
    const [successMsg, setSuccessMsg] = useState('');

    async function saveCategory() {
        try {
            const res = await fetch("http://localhost:4000/api/addCategory", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ category }),
            });

            const data = await res.json();

            if (res.ok) {
                setSuccessMsg('Category added successfully!');
                setCategory('');

                // Hide the message after 3 seconds
                setTimeout(() => {
                    setSuccessMsg('');
                }, 3000);
            } else {
                console.log('Failed to add category:', data.message);
            }
        } catch (error) {
            console.log(error);
        }
    }

    return (
        <div className="min-h-screen flex items-center justify-center bg-gray-100">
            <div className="bg-white p-6 rounded-lg shadow-md w-full max-w-md">
                <h2 className="text-2xl font-semibold text-gray-800 mb-4">Add New Category</h2>

                {successMsg && (
                    <div className="mb-4 p-3 rounded-md bg-gray-700 text-white text-sm text-center transition-opacity duration-300">
                        {successMsg}
                    </div>
                )}

                <input
                    type="text"
                    placeholder="Enter category"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 mb-4"
                />

                <button
                    onClick={saveCategory}
                    className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition duration-200"
                >
                    Add Category
                </button>
            </div>
        </div>
    );
}

export default AddCategory;
