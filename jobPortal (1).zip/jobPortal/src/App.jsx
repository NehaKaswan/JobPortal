import { BrowserRouter, Routes, Route } from "react-router-dom"
import Layout from "./pages/Layout";

// import Header from "./componnets/Header";
import Home from "./pages/Home";
// import Footer from "./componnets/Footer";
import About from "./componnets/About";
import Contact from "./componnets/Contact";
import Jobs from "./componnets/Jobs";
// import { Layout } from "lucide-react";
import Login from "./componnets/Login";
import AdminLayout from "./admin/adminlayout";
import ViewContact from "./admin/viewContact";
import AddCategory from "./admin/AddCategory"
import ViewCategory from "./admin/ViewCategory";
import Addjob from "./admin/Addjob";
import Viewjobs from "./admin/Viewjobs";
import Signup from "./pages/Signup";
import Logina from "./pages/Logina";
import Viewsignup from "./admin/Viewsignup";
import AuthContextProvider from "./context/AuthContextProvider";
import JobUpdate from "./admin/JobUpdate";
import Apply from "./pages/Apply";
function App() {
  return (
    <div className="App">
      <BrowserRouter>
          <AuthContextProvider>
        <Routes>
          <Route path="/" element={<Layout></Layout>}>
            <Route index element={<Home></Home>} />
            <Route path="about" element={<About></About>}></Route>
            <Route path="contact" element={<Contact></Contact>} />
            <Route path="job" element={<Jobs></Jobs>}></Route>
            <Route path="Login" element={<Login></Login>}></Route>
            <Route path="Signup" element={<Signup></Signup>}></Route>
            <Route path="Logina" element ={<Logina></Logina>}></Route>
            <Route path="Apply" element={<Apply></Apply>}></Route>
          </Route>
          <Route path="admin" element={<AdminLayout></AdminLayout>}>
          <Route index element={<ViewContact/>}></Route>
            <Route path="ViewContact" element={<ViewContact></ViewContact>}></Route>
            <Route path="AddCategory" element={<AddCategory></AddCategory>}></Route>
            <Route path="ViewCategory" element={<ViewCategory></ViewCategory>} />
            <Route path="Addjob" element={<Addjob></Addjob>}></Route>
            <Route path="Viewjob" element ={<Viewjobs></Viewjobs>}></Route>
            <Route path="Viewsignup" element={<Viewsignup></Viewsignup>}></Route>
            <Route path="jobupdate/:id" element={<JobUpdate/>}></Route>
          </Route>
        </Routes>
          </AuthContextProvider>
      </BrowserRouter>

    </div>
  );
}

export default App;